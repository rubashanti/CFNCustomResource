import json
import json
import boto3    
import urllib.request
import os

def lambda_handler(event, context):
    s3 = boto3.resource('s3')
    cfn = boto3.client('cloudformation')
    CFN_BUCKET_NAME = event[CFN_BUCKET_NAME]
    region = os.environ['AWS_REGION']
    template_url="https://s3."+region+".amazonaws.com/"+CFN_BUCKET_NAME+"/Failed_testcase.yml"
    StackName="testing-cfn-customresource"
    print(template_url)
    if event['RequestType'] == 'Create':
        response = cfn.create_stack(StackName=StackName,TemplateURL=template_url,Capabilities=['CAPABILITY_IAM'])
        send_response(event, context, "SUCCESS", {"stackname": StackName})

    elif event['RequestType'] == 'Update':
          send_response(event, context, "SUCCESS",{"grapes": "green", "Apple":"red", "Banana":"yellow"})

    elif event['RequestType'] == 'Delete':
        ##1. delete the objects inside the s3
          bucket = s3.Bucket(CFN_BUCKET_NAME)
          bucket.objects.all().delete()
       ##2. delete the stack which was creatted
          response2 = cfn.delete_stack(StackName=StackName)
       ##3. send ok
          send_response(event, context, "SUCCESS",{"grapes": "green", "Apple":"red", "Banana":"yellow"})
    else:
        send_response(event, context, "FAILED",{"grapes": "green", "Apple":"red", "Banana":"yellow"})

def send_response(event, context, response_status, response_data):
    responseUrl = event['ResponseURL']
    print(responseUrl)
    PhysicalResourceId= event.get('PhysicalResourceId',"")
    print (PhysicalResourceId)
    reason = ""
    try:
        cfnresponse.send(event, context, response_status, response_data, PhysicalResourceId, False, reason )
     #   response = http.request('PUT', responseUrl, headers=headers, body=json_responseBody)
    except Exception as e:
        print("send(..) failed executing http.request(..):", e)


